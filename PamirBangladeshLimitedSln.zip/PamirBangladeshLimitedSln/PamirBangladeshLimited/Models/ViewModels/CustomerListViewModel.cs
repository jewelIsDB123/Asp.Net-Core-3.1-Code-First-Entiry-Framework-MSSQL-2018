﻿using PamirBangladeshLimited.Models.Classes;
using System;
using System.ComponentModel.DataAnnotations;

namespace PamirBangladeshLimited.Models.ViewModels
{
    public class CustomerListViewModel
    {
        public int CustomerID { get; set; }
        [Required(ErrorMessage = "Name Is Required")]
        public string Name { get; set; }
        public DateTime DoB { get; set; }
        [Required(ErrorMessage = "Team Is Required")]
        public string Team { get; set; }
        [Required(ErrorMessage = "Email Is Required")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Phone Is Required")]
        public string Phone { get; set; }
        public decimal Salary { get; set; }
        public int CustomerTypeID { get; set; }
        public string CustomerTypeName { get; set; }
        public virtual CustomerType CustomerTypes { get; set; }
    }
}
