﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PamirBangladeshLimited.Models.ViewModels
{
    public class CreateCustomerTypeViewModel
    {
        public int CustomerTypeID { get; set; }
        [Required(ErrorMessage = "CustomerType Is Required")]
        public string CustomerTypeName { get; set; }
    }
}
