﻿using Microsoft.AspNetCore.Http;
using PamirBangladeshLimited.Models.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PamirBangladeshLimited.Models.Classes
{
    public class Customer
    {
        [Key]
        public int CustomerID { get; set; }
        public string Name { get; set; }
        public DateTime DoB { get; set; }
        public string Team { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public decimal Salary { get; set; }
        public int CustomerTypeID { get; set; }
        public virtual CustomerType CustomerTypes { get; set; }
    }
}
