﻿using PamirBangladeshLimited.Models.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PamirBangladeshLimited.Models.Classes
{
    public class CustomerType
    {
        public int CustomerTypeID { get; set; }
        public string CustomerTypeName { get; set; }
        public virtual ICollection<Customer> Customers { get; set; }
    }
}
