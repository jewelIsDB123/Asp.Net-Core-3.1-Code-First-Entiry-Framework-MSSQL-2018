﻿using Microsoft.EntityFrameworkCore;
using PamirBangladeshLimited.BLL.Interfaces;
using PamirBangladeshLimited.Data;
using PamirBangladeshLimited.Models.Classes;
using PamirBangladeshLimited.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PamirBangladeshLimited.BLL.Repository
{
    public class CustomersRepository : ICustomerRepository
    {
        private readonly AppDbContext _context;

        public CustomersRepository(AppDbContext context)
        {
            _context = context;
        }
        public void DeleteCustomer(int id)
        {
            Customer delCustomer = GetCustomerById(id);
            _context.Customers.Remove(delCustomer);
            _context.SaveChanges();
        }

        public void DeleteCustomerType(int id)
        {
            CustomerType delCustomerType = GetCustomerTypeById(id);
            _context.CustomerTypes.Remove(delCustomerType);
            _context.SaveChanges();
        }

        public List<CreateCustomerModel> GetCreateCustomers()
        {
            List<CreateCustomerModel> createCustomerModels = new List<CreateCustomerModel>();
            createCustomerModels = _context.Customers.Select(p => new CreateCustomerModel
            {
                Name = p.Name,
                DoB = p.DoB,
                Team = p.Team,
                Email = p.Email,
                Phone = p.Phone,
                Salary = p.Salary,
                CustomerTypeID = p.CustomerTypes.CustomerTypeID
            }).ToList();
            return createCustomerModels;
        }

        public Customer GetCustomerById(int id)
        {

            Customer customer = _context.Customers.SingleOrDefault(p => p.CustomerID == id);
            return customer;
        }

        public List<CustomerListViewModel> GetCustomerList()
        {
            List<CustomerListViewModel> list = _context.Customers.Select(p => new CustomerListViewModel
            {
                CustomerID = p.CustomerID,
                Name = p.Name,
                DoB = p.DoB,
                Team = p.Team,
                Email = p.Email,
                Phone = p.Phone,
                Salary = p.Salary,
                CustomerTypeID = p.CustomerTypeID,
                CustomerTypeName = p.CustomerTypes.CustomerTypeName,
            }).ToList();
            return list;
        }
        public CustomerType GetCustomerTypeById(int CustomerTypeID)
        {
            CustomerType customerTypes = _context.CustomerTypes.SingleOrDefault(g => g.CustomerTypeID == CustomerTypeID);
            return customerTypes;
        }
        public List<CustomerType> GetCustomerTypes()
        {
            List<CustomerType> customerTypeList = _context.CustomerTypes.ToList();
            return customerTypeList;
        }

        public void SaveCustomer(Customer obj)
        {
            _context.Customers.Add(obj);
            _context.SaveChanges();
        }
        public void SaveCustomerType(CustomerType obj)
        {
            _context.CustomerTypes.Add(obj);
            _context.SaveChanges();
        }

        public void UpdateCustomer(Customer obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public void UpdateCustomerType(CustomerType obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
