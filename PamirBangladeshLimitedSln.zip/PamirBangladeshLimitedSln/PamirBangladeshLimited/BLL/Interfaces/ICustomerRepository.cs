﻿using PamirBangladeshLimited.Models.Classes;
using PamirBangladeshLimited.Models.ViewModels;
using System.Collections.Generic;

namespace PamirBangladeshLimited.BLL.Interfaces
{
    public interface ICustomerRepository
    {
        List<CustomerListViewModel> GetCustomerList();
        List<CreateCustomerModel> GetCreateCustomers();
        void UpdateCustomer(Customer obj);
        void SaveCustomer(Customer obj);
        void DeleteCustomer(int id);
        Customer GetCustomerById(int id);
        List<CustomerType> GetCustomerTypes();
        void SaveCustomerType(CustomerType obj);
        void UpdateCustomerType(CustomerType obj);
        CustomerType GetCustomerTypeById(int CustomerTypeID);
        void DeleteCustomerType(int id);
    }
}
