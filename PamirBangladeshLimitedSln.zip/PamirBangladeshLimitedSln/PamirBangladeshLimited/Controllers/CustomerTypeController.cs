﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PamirBangladeshLimited.Models.Classes;
using PamirBangladeshLimited.Models.ViewModels;
using PamirBangladeshLimited.Data;
using PamirBangladeshLimited.BLL.Interfaces;

namespace PamirBangladeshLimited.Controllers
{
    public class CustomerTypeController : Controller
    {
        private readonly ICustomerRepository _repoObj;
        private readonly AppDbContext _context;

        public CustomerTypeController(ICustomerRepository repoObj, AppDbContext context)
        {
            _repoObj = repoObj;
            _context = context;
        }
        public ActionResult CustomerTypeList()
        {
            List<CustomerType> CustomerTypeList = _repoObj.GetCustomerTypes();
            return View(CustomerTypeList);
        }
        [HttpGet]
        public ActionResult AddCustomerType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCustomerType(CreateCustomerTypeViewModel viewobj)
        {
            CustomerType CustomerTypeObj = new CustomerType();
            CustomerTypeObj.CustomerTypeName = viewobj.CustomerTypeName;
            _repoObj.SaveCustomerType(CustomerTypeObj);
            RedirectToAction("CustomerTypeList");
            return RedirectToAction("CustomerTypeList");
        }
        [HttpGet]
        public ActionResult EditCustomerType(int id)
        {
            CustomerType CustomerTypeObj = _context.CustomerTypes.SingleOrDefault(g => g.CustomerTypeID == id);
            CreateCustomerTypeViewModel CustomerTypeObj2 = new CreateCustomerTypeViewModel();
            if (CustomerTypeObj != null)
            {
                CustomerTypeObj2.CustomerTypeName = CustomerTypeObj.CustomerTypeName;
            }

            return View(CustomerTypeObj);
        }
        [HttpPost]
        public ActionResult EditCustomerType(CreateCustomerTypeViewModel viewObj)
        {
            CustomerType CustomerTypeObj = new CustomerType();
            CustomerTypeObj.CustomerTypeName = viewObj.CustomerTypeName;
            CustomerTypeObj.CustomerTypeID = viewObj.CustomerTypeID;
            _repoObj.UpdateCustomerType(CustomerTypeObj);
            return RedirectToAction("CustomerTypeList");
        }
        public ActionResult DeleteCustomerType(int id)
         {
            CustomerType CustomerTypeobj = _repoObj.GetCustomerTypeById(id);
            if (CustomerTypeobj != null)
            {
                _repoObj.DeleteCustomerType(CustomerTypeobj.CustomerTypeID);
                return RedirectToAction("CustomerTypeList");
            }
            return View(CustomerTypeobj);
        }
    }
}
