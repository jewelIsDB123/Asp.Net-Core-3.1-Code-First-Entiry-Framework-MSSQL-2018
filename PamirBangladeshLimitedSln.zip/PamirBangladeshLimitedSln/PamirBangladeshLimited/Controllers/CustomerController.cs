﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using PamirBangladeshLimited.Models.Classes;
using PamirBangladeshLimited.Models.ViewModels;
using PagedList;
using PamirBangladeshLimited.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using PamirBangladeshLimited.BLL.Interfaces;
using System.Runtime.InteropServices.ComTypes;
using Microsoft.AspNetCore.Hosting.Server;

namespace PamirBangladeshLimited.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerRepository _repoObj;
        private readonly AppDbContext _context;
        public CustomerController(ICustomerRepository repoObj, AppDbContext context)
        {
            _repoObj = repoObj;
            _context = context;
        }
        public ActionResult Index(string SearchString, string CurrentFilter, string sortOrder, int? Page)
        {
            ViewBag.SortNameParam = string.IsNullOrEmpty(sortOrder) ? "name_des" : "";
            ViewBag.Salary = string.IsNullOrEmpty(sortOrder) ? "salary_des" : "";
            if (SearchString != null)
            {
                Page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            ViewBag.CurrentFilter = SearchString;

            List<CustomerListViewModel> customerList = _repoObj.GetCustomerList();

            if (!string.IsNullOrEmpty(SearchString))
            {
                customerList = customerList.Where(n => n.Name.ToUpper().Contains(SearchString.ToUpper())).ToList();
            }
            switch (sortOrder)
            {
                case "name_des":
                    customerList = customerList.OrderByDescending(n => n.Name).ToList();
                    break;
                case "salary_des":
                    customerList = customerList.OrderByDescending(n => n.Salary).ToList();
                    break;
                default:
                    customerList = customerList.OrderBy(n => n.Name).ToList();
                    break;
            }
            int PageSize = 6;
            int PageNumber = (Page ?? 1);
            return View("Index", customerList.ToPagedList(PageNumber, PageSize));
        }
        public ActionResult Create()
        {
            CreateCustomerModel crObj = new CreateCustomerModel();
            crObj.customerTypeList = _context.CustomerTypes.ToList();
            return View(crObj);
        }
        public ActionResult AddOrEdit(CreateCustomerModel viewObj)
        {
            var result = false;
            Customer CustomerObj = new Customer();
            CustomerObj.Name = viewObj.Name;
            CustomerObj.DoB = viewObj.DoB;
            CustomerObj.Team = viewObj.Team;
            CustomerObj.Email = viewObj.Email;
            CustomerObj.Phone = viewObj.Phone;
            CustomerObj.Salary = viewObj.Salary;
            CustomerObj.CustomerTypeID = viewObj.CustomerTypeID;
            if (ModelState.IsValid)
            {
                if (viewObj.CustomerID == 0)
                {
                    _repoObj.SaveCustomer(CustomerObj);
                    result = true;
                }
                else
                {
                    CustomerObj.CustomerID = viewObj.CustomerID;
                    _repoObj.UpdateCustomer(CustomerObj);
                    result = true;
                }
            }
            if (result)
            {
                return RedirectToAction("Index");
            }
            else
            {
                if (viewObj.CustomerID == 0)
                {
                    CreateCustomerModel crObj = new CreateCustomerModel();
                    crObj.customerTypeList = _context.CustomerTypes.ToList();
                    return View("Create", crObj);
                }
                else
                {
                    CreateCustomerModel crObj = new CreateCustomerModel();
                    crObj.customerTypeList = _context.CustomerTypes.ToList();
                    return View("Edit", crObj);
                }
            }

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Customer CustomerObj = _repoObj.GetCustomerById(id);
            CreateCustomerModel viewObj = new CreateCustomerModel();
            if (CustomerObj != null)
            {
                viewObj.CustomerID = CustomerObj.CustomerID;
                viewObj.Name = CustomerObj.Name;
                viewObj.DoB = CustomerObj.DoB;
                viewObj.Team = CustomerObj.Team;
                viewObj.Email = CustomerObj.Email;
                viewObj.Phone = CustomerObj.Phone;
                viewObj.Salary = CustomerObj.Salary;
                viewObj.CustomerTypeID = CustomerObj.CustomerTypeID;
                viewObj.customerTypeList = _context.CustomerTypes.ToList();
            }
            return View(viewObj);
        }
        public ActionResult Delete(int id)
        {
            Customer obj = _repoObj.GetCustomerById(id);
            _repoObj.DeleteCustomer(obj.CustomerID);
            return RedirectToAction("Index");
        }


        //[HttpGet]
        //public ActionResult Delete(int id)
        //{
        //    Customer CustomerObj = _repoObj.GetCustomerById(id);
        //    CreateCustomerModel viewObj = new CreateCustomerModel();
        //    if (CustomerObj != null)
        //    {
        //        viewObj.CustomerID = CustomerObj.CustomerID;
        //        viewObj.Name = CustomerObj.Name;
        //        viewObj.DoB = CustomerObj.DoB;
        //        viewObj.Team = CustomerObj.Team;
        //        viewObj.Email = CustomerObj.Email;
        //        viewObj.Phone = CustomerObj.Phone;
        //        viewObj.Salary = CustomerObj.Salary;
        //        viewObj.CustomerTypeID = CustomerObj.CustomerTypeID;

        //    }
        //   return View(viewObj);
        //}
        //[HttpPost]
        //[ActionName("Delete")]
        //public ActionResult DeleteConfirm(int id)
        //{
        //    Customer CustomerObj = _repoObj.GetCustomerById(id);
        //    if (CustomerObj != null)
        //    {
        //        _repoObj.DeleteCustomer(CustomerObj.CustomerID);
        //        return RedirectToAction("Index");
        //    }
        //    return View(CustomerObj);
        //}

    }
}

